"use client";

import React from "react";
import Globe3D from "./hero";

export function Demo() {
    return (
        <Globe3D />
    );
}